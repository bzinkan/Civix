export default function DashboardPage() {
  return (
    <section>
      <h1>Dashboard</h1>
      <p className="muted">
        This is a placeholder for authenticated users. Soon you will find saved
        reports, compliance checklists, and account settings here.
      </p>
    </section>
  );
}
