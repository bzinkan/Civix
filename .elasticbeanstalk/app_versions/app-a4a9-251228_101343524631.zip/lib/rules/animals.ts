export const animalRules = [
  {
    keyword: "dog",
    answer: "Most jurisdictions require dogs to be licensed and leashed."
  },
  {
    keyword: "chicken",
    answer: "Backyard chickens are often limited by lot size and coop placement."
  }
];
