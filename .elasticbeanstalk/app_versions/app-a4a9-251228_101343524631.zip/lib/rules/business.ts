export const businessRules = [
  {
    keyword: "license",
    answer: "Business licenses are usually required before opening to the public."
  },
  {
    keyword: "signage",
    answer: "Exterior signage often requires design review approval."
  }
];
