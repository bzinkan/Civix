export const zoningRules = [
  {
    keyword: "fence",
    answer: "Fences may be restricted in front yards; check local setback rules."
  },
  {
    keyword: "garage",
    answer: "Detached garages typically require a zoning review and permit."
  }
];
